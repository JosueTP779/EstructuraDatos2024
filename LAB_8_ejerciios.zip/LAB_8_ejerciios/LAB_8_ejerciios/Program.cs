﻿//ejercicio_1
//using System;
//using System.Collections.Generic;
//using System.Linq;

//class Ejercicio_1
//{
//    static void Main()
//    {

//        Console.WriteLine("Ingrese numeros separados por las comas:");
//        string input = Console.ReadLine();

//        List<int> numeros = input.Split(',')
//                                 .Select(n => Convert.ToInt32(n.Trim()))
//                                 .ToList();

//        List<int> numerosPrimos = ObtenerNumerosPrimos(numeros);
//        Console.WriteLine("Números primos:");
//        foreach (int primo in numerosPrimos)
//        {
//            Console.WriteLine(primo);
//        }
//    }
//    public static List<int> ObtenerNumerosPrimos(List<int> numeros)
//    {
//        return numeros.Where(n => EsPrimo(n)).ToList();
//    }

//    public static bool EsPrimo(int numero)
//    {
//        if (numero <= 1) return false;
//        if (numero == 2) return true;
//        if (numero % 2 == 0) return false;

//        var limite = (int)Math.Sqrt(numero);
//        for (int i = 3; i <= limite; i += 2)
//        {
//            if (numero % i == 0) return false;
//        }

//        return true;
//    }
//}


//ejercicio_2
//using System;
//using System.Collections.Generic;
//using System.Linq;

//class Ejercicio_2
//{
//    static void Main()
//    {

//        Console.WriteLine("Ingrese palabras separadas por comas:");
//        string inputPalabras = Console.ReadLine();

//        List<string> palabras = inputPalabras.Split(',')
//                                             .Select(p => p.Trim())
//                                             .ToList();

//        Console.WriteLine("Con que letra inicial desea filtrar las palabras:");
//        char letraInicial = Console.ReadLine()[0];

//        List<string> palabrasFiltradas = ObtenerPalabrasConLetraInicial(palabras, letraInicial);
//        Console.WriteLine($"Palabras que empiezan con '{letraInicial}':");
//        palabrasFiltradas.ForEach(Console.WriteLine);
//    }

//    public static List<string> ObtenerPalabrasConLetraInicial(List<string> palabras, char letraInicial)
//    {
//        return palabras.Where(p => p.StartsWith(letraInicial.ToString(), StringComparison.OrdinalIgnoreCase)).ToList();
//    }
//}


//Ejercicio_3:
//using System;
//using System.Collections.Generic;
//using System.Linq;

//class Ejercicio_3
//{
//    static void Main()
//    {

//        Console.WriteLine("Digite numeros separados por comas:");
//        string inputNumeros = Console.ReadLine();

//        List<int> numeros = inputNumeros.Split(',')
//                                        .Select(int.Parse)
//                                        .ToList();

//        Console.WriteLine("Digite el divisor:");
//        int divisor = int.Parse(Console.ReadLine());

//        List<int> numerosDivisibles = GetDivisibleNumbers(numeros, divisor);
//        Console.WriteLine($"Números divisibles son:");
//        numerosDivisibles.ForEach(Console.WriteLine);
//    }

//    public static List<int> GetDivisibleNumbers(List<int> numbers, int divisor)
//    {
//        return numbers.Where(n => n % divisor == 0).ToList();
//    }
//}



//Ejercicio_4:
//using System;
//using System.Collections.Generic;
//using System.Linq;

//class Program
//{
//    static void Main()
//    {

//        Console.WriteLine("Digite una lista de numeros:");
//        string inputLista1 = Console.ReadLine();
//        List<int> lista1 = inputLista1.Split(',')
//                                      .Select(int.Parse)
//                                      .ToList();

//        Console.WriteLine("Digite otra lista de numeros:");
//        string inputLista2 = Console.ReadLine();
//        List<int> lista2 = inputLista2.Split(',')
//                                      .Select(int.Parse)
//                                      .ToList();

//        List<int> interseccion = GetIntersection(lista1, lista2);
//        Console.WriteLine("Los numeros que se repiten en ambas listas son:");
//        interseccion.ForEach(Console.WriteLine);
//    }
//    public static List<int> GetIntersection(List<int> list1, List<int> list2)
//    {
//        return list1.Intersect(list2).ToList();
//    }
//}


//Ejercicio_5
//using System;
//using System.Collections.Generic;
//using System.Linq;

//class Ejercicio_5
//{
//    static void Main()
//    {

//        Console.WriteLine("Digite numeros para el primer conjunto:");
//        List<int> conjunto1 = Console.ReadLine().Split(',')
//                                                .Select(int.Parse)
//                                                .ToList();

//        Console.WriteLine("Digite numeros para el segundo conjunto:");
//        List<int> conjunto2 = Console.ReadLine().Split(',')
//                                                .Select(int.Parse)
//                                                .ToList();

//        List<int> resultado = conjunto1.Except(conjunto2).ToList();

//        Console.WriteLine("La diferencia del primer conjunto con el segundo conjunto es:");
//        resultado.ForEach(Console.WriteLine);
//    }
//}



//ejercicio_6
//using System;
//using System.Collections.Generic;
//using System.Linq;

//class Ejercicio_7
//{
//    static void Main()
//    {

//        Console.WriteLine("Digite el primer conjunto de numeros:");
//        List<int> conjunto1 = Console.ReadLine().Split(',')
//                                                .Select(int.Parse)
//                                                .ToList();

//        Console.WriteLine("Digite el segundo conjunto de numeros:");
//        List<int> conjunto2 = Console.ReadLine().Split(',')
//                                                .Select(int.Parse)
//                                                .ToList();

//        List<int> resultado = conjunto2.Except(conjunto1).ToList();

//        Console.WriteLine("La diferencia del segundo conjunto con el primer conjunto es:");
//        resultado.ForEach(Console.WriteLine);
//    }
//}



//ejercicio_7
//using System;
//using System.Collections.Generic;
//using System.Linq;

//class Ejercicio_7
//{
//    static void Main()
//    {

//        Console.WriteLine("Ingrese palabras separadas por comas:");
//        List<string> palabras = Console.ReadLine().Split(',')
//                                                  .Select(p => p.Trim())
//                                                  .ToList();

//        List<List<string>> anagramas = Anagrams(palabras);

//        Console.WriteLine("Anagramas encontrados:");
//        foreach (var grupo in anagramas)
//        {
//            Console.WriteLine(string.Join(", ", grupo));
//        }
//    }

//    public static List<List<string>> Anagrams(List<string> words)
//    {
//        return words.GroupBy(word => new string(word.OrderBy(c => c).ToArray()))
//                    .Select(group => group.ToList())
//                    .ToList();
//    }
//}



//Ejercicio_8
//using System;
//using System.Collections.Generic;
//using System.Linq;

//class Ejercicio_8
//{
//    static void Main()
//    {
//        Console.WriteLine("Ingrese una lista de palabras separadas por comas:");
//        List<string> palabras = Console.ReadLine().Split(',')
//                                                  .Select(p => p.Trim())
//                                                  .ToList();

//        List<string> palindromas = Palindromes(palabras);

//        Console.WriteLine("Palabras palíndromas encontradas:");
//        palindromas.ForEach(Console.WriteLine);
//    }

//    public static List<string> Palindromes(List<string> palabras)
//    {
//        return palabras.Where(palabra => EsPalindromo(palabra)).ToList();
//    }

//    public static bool EsPalindromo(string palabra)
//    {
//        palabra = palabra.ToLower();
//        return palabra.SequenceEqual(palabra.Reverse());
//    }
//}






//ejercicio_9
//using System;
//using System.Collections.Generic;
//using System.Linq;

//class Ejercicio_9
//{
//    static void Main()
//    {
//        Console.WriteLine("Ingrese conjuunto de palabras separados por comas:");
//        var palabras = Console.ReadLine().Split(',').Select(p => p.Trim());

//        Console.WriteLine("Digite la longitud para filtrar las palabras:");
//        var longitud = int.Parse(Console.ReadLine());

//        Console.WriteLine($"Palabras encontradas son:");
//        palabras.Where(word => word.Length == longitud).ToList().ForEach(Console.WriteLine);
//    }
//}



//Ejercicio_10
//using System;
//using System.Linq;

//class Ejercico_10
//{
//    static void Main()
//    {
//        Console.WriteLine("Ingrese conjunto de palabras sepradas por comas:");
//        var palabras = Console.ReadLine().Split(',').Select(p => p.Trim());

//        Console.WriteLine("¿Que letra desea buscar:");
//        var letra = Console.ReadLine()[0];

//        Console.WriteLine($"Estas palabras con la letra buscada son: ");
//        palabras.Where(word => word.Contains(letra)).ToList().ForEach(Console.WriteLine);
//    }
//}



//Ejercicio_11
//using System;
//using System.Collections.Generic;
//using System.Linq;

//class Ejerccicio_11
//{
//    static void Main()
//    {
//        Console.WriteLine("Digite un conjunto de numeros separados por las comas:");
//        var num = Console.ReadLine().Split(',').Select(int.Parse);

//        Console.WriteLine("Números ordenados:");
//        num.OrderBy(n => n).ToList().ForEach(Console.WriteLine);
//    }
//}




//Ejercicio_12
//using System;
//using System.Collections.Generic;
//using System.Linq;

//class Ejercicio_12
//{
//    static void Main()
//    {
//        Console.WriteLine("Ingrese un conjunto de numeros separados por las comas: ");
//        var num = Console.ReadLine().Split(',').Select(int.Parse);
//        Console.WriteLine("Números ordenados: " + string.Join(", ", num.OrderByDescending(n => n)));
//    }
//}




//ejercicio_13
//using System;
//using System.Collections.Generic;
//using System.Linq;

//class Ejercicio_13
//{
//    static void Main()
//    {
//        Console.WriteLine("Ingrese un conjunto de numeros seprados por las comas:");
//        var num = Console.ReadLine().Split(',').Select(int.Parse);

//        Console.WriteLine("Números duplicados encontrados: " + string.Join(", ", num.GroupBy(n => n).Where(group => group.Count() > 1).Select(group => group.Key)));
//    }
//}



//Ejericio_14
//using System;
//using System.Collections.Generic;
//using System.Linq;

//class Ejercicio_14
//{
//    static void Main()
//    {
//        Console.WriteLine("Ingrese un conjuunto de numeros separados por comas:");
//        var numeros = Console.ReadLine().Split(',').Select(int.Parse);

//        Console.WriteLine("Números no duplicados: " + string.Join(", ", numeros.GroupBy(n => n).Where(g => g.Count() == 1).Select(g => g.Key)));
//    }
//}



//Ejercicio_15
//using System;
//using System.Collections.Generic;
//using System.Linq;

//class Ejercicio_15
//{
//    static void Main()
//    {
//        Console.WriteLine("Ingrese un conjunto de numeros separados por las comas:");
//        var numeros = Console.ReadLine().Split(',').Select(int.Parse);

//        var numerosPrimosOrdenados = numeros.Where(n => EsPrimo(n)).OrderBy(n => n);

//        Console.WriteLine("Números primos ordenados: " + string.Join(", ", numerosPrimosOrdenados));
//    }

//    static bool EsPrimo(int num)
//    {
//        if (num <= 1) return false;
//        if (num == 2) return true;
//        if (num % 2 == 0) return false;

//        var limite = (int)Math.Sqrt(num);
//        for (int i = 3; i <= limite; i += 2)
//        {
//            if (num % i == 0) return false;
//        }

//        return true;
//    }
//}





//ejercicio_16
//using System;
//using System.Collections.Generic;
//using System.Linq;

//class Ejercicio_16
//{
//    static void Main()
//    {
//        Console.WriteLine("Ingrese un conjunto de palabras seprados por las comas:");
//        var palabras = Console.ReadLine().Split(',').Select(p => p.Trim());

//        var palindromosOrdenados = palabras.Where(p => EsPalindromo(p)).OrderBy(p => p);

//        Console.WriteLine("Palíndromos ordenados: " + string.Join(", ", palindromosOrdenados));
//    }

//    static bool EsPalindromo(string palabra)
//    {
//        return palabra.SequenceEqual(palabra.Reverse());
//    }
//}




//Ejerccio_17
//using System;
//using System.Collections.Generic;
//using System.Linq;

//class Ejercicio_17
//{
//    static void Main()
//    {
//        Console.WriteLine("Ingrese un conjunto de palabras seoaradas por las comas:");
//        var palabras = Console.ReadLine().Split(',').Select(p => p.Trim());

//        Console.WriteLine("Ingrese la longitud: ");
//        int longitud = int.Parse(Console.ReadLine());

//        var palabrasFiltradas = palabras.Where(p => p.Length == longitud).OrderBy(p => p);

//        Console.WriteLine($"Palabras de longitud {longitud} ordenadas: " + string.Join(", ", palabrasFiltradas));
//    }
//}





