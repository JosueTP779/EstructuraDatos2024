﻿namespace CalculadoraSueldoArquitecto
{
    public class Arquitecto
    {
        public int Codigo { get; set; }
        public string Nombre { get; set; }
        public string CondicionContrato { get; set; }
        public string Especialidad { get; set; }
        public string TipoActividad { get; set; }
        public string TipoAfiliacion { get; set; }

        public Arquitecto(int codigo, string nombre, string condicionContrato, string especialidad, string tipoActividad, string tipoAfiliacion)
        {
            Codigo = codigo;
            Nombre = nombre;
            CondicionContrato = condicionContrato;
            Especialidad = especialidad;
            TipoActividad = tipoActividad;
            TipoAfiliacion = tipoAfiliacion;
        }

        public double CalcularSueldoBase()
        {
            double sueldoBase = 0;

            if (CondicionContrato == "Estable")
            {
                if (TipoActividad == "Supervisión de Obras")
                {
                    sueldoBase = 4000;
                }
                else if (TipoActividad == "Supervisión de Vías")
                {
                    sueldoBase = 6000;
                }
            }
            else if (CondicionContrato == "Contratado")
            {
                if (TipoActividad == "Supervisión de Obras")
                {
                    sueldoBase = 2000;
                }
                else if (TipoActividad == "Supervisión de Vías")
                {
                    sueldoBase = 4500;
                }
            }

            return sueldoBase;
        }

        public double CalcularBonificacion()
        {
            double bonificacion = 0;

            if (Especialidad == "Estructuras")
            {
                bonificacion = 0.16;
            }
            else if (Especialidad == "Recursos Hidricos")
            {
                bonificacion = 0.18;
            }

            return bonificacion * CalcularSueldoBase();
        }

        public double CalcularSueldoBruto()
        {
            return CalcularSueldoBase() + CalcularBonificacion();
        }

        public double CalcularDescuento()
        {
            double descuento = 0;

            if (TipoAfiliacion == "AFP")
            {
                descuento = 0.15;
            }
            else if (TipoAfiliacion == "SNP")
            {
                descuento = 0.08;
            }

            return descuento * CalcularSueldoBruto();
        }

        public double CalcularSueldoNeto()
        {
            return CalcularSueldoBruto() - CalcularDescuento();
        }
    }
}
