﻿using System;
using System.Windows.Forms;

namespace CalculadoraSueldoArquitecto
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                int codigo = int.Parse(txtCodigo.Text);
                string nombre = txtNombre.Text;
                string condicionContrato = cmbCondicionContrato.SelectedItem.ToString();
                string especialidad = cmbEspecialidad.SelectedItem.ToString();
                string tipoActividad = cmbTipoActividad.SelectedItem.ToString();
                string tipoAfiliacion = cmbTipoAfiliacion.SelectedItem.ToString();

                Arquitecto arquitecto = new Arquitecto(codigo, nombre, condicionContrato, especialidad, tipoActividad, tipoAfiliacion);

                double sueldoBruto = arquitecto.CalcularSueldoBruto();
                double sueldoNeto = arquitecto.CalcularSueldoNeto();

                lblSueldoBruto.Text = "Sueldo Bruto: " + sueldoBruto.ToString("C");
                lblSueldoNeto.Text = "Sueldo Neto: " + sueldoNeto.ToString("C");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtCodigo.Clear();
            txtNombre.Clear();
            cmbCondicionContrato.SelectedIndex = -1;
            cmbEspecialidad.SelectedIndex = -1;
            cmbTipoActividad.SelectedIndex = -1;
            cmbTipoAfiliacion.SelectedIndex = -1;
            lblSueldoBruto.Text = "Sueldo Bruto: ";
            lblSueldoNeto.Text = "Sueldo Neto: ";
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
