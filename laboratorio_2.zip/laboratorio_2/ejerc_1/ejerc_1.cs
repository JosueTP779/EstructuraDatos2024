﻿using System;

class Operaciones_Matematicas
{
    static double Suma(double num1, double num2)
    {
        return num1 + num2;
    }

    static double Resta(double num1, double num2)
    {
        return num1 - num2;
    }

    static double Multiplicacion(double num1, double num2)
    {
        return num1 * num2;
    }

    static double Division(double num1, double num2)
    {
        if (num2 != 0)
        {
            return num1 / num2;
        }
        else
        {
            Console.WriteLine("Error: No es posible la division con 0.");
            return double.NaN;
        }
    }

    static void Main(string[] args)
    {
        Console.WriteLine("digite un número:");
        double a = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("digite un número:");
        double b = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine($"La suma de {a} y {b} es: {Suma(a, b)}");
        Console.WriteLine($"La resta de {a} y {b} es: {Resta(a, b)}");
        Console.WriteLine($"La multiplicación de {a}  y  {b}  es:  {Multiplicacion(a, b)}");
        Console.WriteLine($"La división de {a}  y  {b}  es:  {Division(a, b)}");
    }
}
