﻿using System;

class Fibonaci
{
    static void Main(string[] args)
    {
        int cantNum = 10;
        int[] fibonacci = Generar_Fibonacci(cantNum);

        
        Console.WriteLine("Los primeros 10 números  son:");
        foreach (int num in fibonacci)
        {
            Console.Write(num + " ");
        }
    }

    static int[] Generar_Fibonacci(int cantidad_Num)
    {
        int[] fibonacci = new int[cantidad_Num];

        // Los primeros dos números de la serie Fibonacci son 0 y 1
        fibonacci[0] = 0;
        fibonacci[1] = 1;

        // Generamos los siguientes números
        for (int i = 2; i < cantidad_Num; i++)
        {
            fibonacci[i] = fibonacci[i - 1] + fibonacci[i - 2];
        }

        return fibonacci;
    }
}
