﻿using System;

class Ordenar_Numeros
{
    static void Main(string[] args)
    {
        Console.WriteLine("digite los números, separados por un espacio:");
        string[] numStr = Console.ReadLine().Split(' ');

        int[] lista_numeros = new int[numStr.Length];
        for (int i = 0; i < numStr.Length; i++)
        {
            lista_numeros[i] = Convert.ToInt32(numStr[i]);
        }

        Array.Sort(lista_numeros);

        Console.WriteLine("Números ordenados de menor a mayor:");
        foreach (int numero in lista_numeros)
        {
            Console.Write(numero + " ");
        }
    }
}
