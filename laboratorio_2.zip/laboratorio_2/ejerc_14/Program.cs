﻿using System;

class Area_de_un_circulo
{
    static void Main(string[] args)
    {
        Console.WriteLine("digite el radio del circulo:");
        double radio = Convert.ToDouble(Console.ReadLine());

        double area = Math.PI * radio * radio;

        Console.WriteLine($"El área del círculo es: {area}");
    }
}
