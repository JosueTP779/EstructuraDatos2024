﻿using System;

class Suma_Digitos
{
    static int Suma_digitos(int numero)
    {
        int suma = 0;
        while (numero != 0)
        {
            suma += numero % 10; 
            numero /= 10; 
        }

        return suma;
    }
    static void Main(string[] args)
    {
        Console.WriteLine("ingresa un número entero:");
        int num = Convert.ToInt32(Console.ReadLine());

        int sumDigitos = Suma_digitos(num);

        Console.WriteLine($"La suma de los dígitos de {num} es: {sumDigitos}");
    }

    
}
