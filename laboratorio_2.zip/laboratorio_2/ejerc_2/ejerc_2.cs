﻿using System;

class Paridad
{
    static string Par_Impar(int numero)
    {
        // Verificamos
        if (numero % 2 == 0)
        {
            return "par";
        }
        else
        {
            return "impar";
        }
    }

    static void Main(string[] args)
    {
        Console.WriteLine("Digite un número:");
        int numero = Convert.ToInt32(Console.ReadLine());

        // Llamamos a la funcion
        string paridad = Par_Impar(numero);

        Console.WriteLine($"El número {numero} es {paridad}.");
    }
}
