﻿using System;

class AreaTrianguo
{
    static double Area(double baseT, double alturaT)
    {
        return (baseT * alturaT) / 2;
    }

    static void Main(string[] args)
    {
        Console.WriteLine("digite la base del triángulo:");
        double Base = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("digite la altura del triángulo:");
        double Altura = Convert.ToDouble(Console.ReadLine());

        double area_Triangulo = Area(Base, Altura);

        Console.WriteLine($"El área del triángulo es: {area_Triangulo}");
    }
}
