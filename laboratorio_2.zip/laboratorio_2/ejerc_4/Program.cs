﻿using System;

class FACTORIAL
{
    static long Factorial(int num)
    {
        if (num == 0 || num == 1)
        {
            return 1;
        }
        else
        {
            return num * Factorial(num - 1);
        }
    }

    static void Main(string[] args)
    {
        Console.WriteLine("digite un numero para hallar el factorial:");
        int numero = Convert.ToInt32(Console.ReadLine());

        long factorial = Factorial(numero);
        Console.WriteLine($"El factorial es: {factorial}");
    }
}
