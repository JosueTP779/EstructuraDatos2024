﻿using System;

class Numeros_primos
{
    static void Main(string[] args)
    {
        Console.WriteLine("digite un numero:");
        int num = Convert.ToInt32(Console.ReadLine());

        bool esPrimo = true;

        if (num <= 1)
        {
            esPrimo = false;
        }
        else
        {
            for (int i = 2; i <= num / 2; i++)
            {
                if (num % i == 0)
                {
                    esPrimo = false;
                    break;
                }
            }
        }

        if (esPrimo)
        {
            Console.WriteLine($"{num} es un número primo.");
        }
        else
        {
            Console.WriteLine($"{num} no es un número primo.");
        }
    }
}
