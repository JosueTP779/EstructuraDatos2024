﻿using System;

class Invertir_cadena
{
    static void Main(string[] args)
    {
        Console.WriteLine("ingrese una frase:");
        string texto = Console.ReadLine();

        string textoInvertido = new string(texto.Reverse().ToArray());

        Console.WriteLine($"La frase invertida es: {textoInvertido}");
    }
}
