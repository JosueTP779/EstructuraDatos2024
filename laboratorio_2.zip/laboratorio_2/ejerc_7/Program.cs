﻿using System;

class Rangos
{
    static void Main(string[] args)
    {
        Console.WriteLine("digite el número inicial del rango:");
        int X = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("digite el número final del rango:");
        int Y = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine($"el rango es: [{X},{Y}]");
        int sumPares = 0;

        for (int i = X; i <= Y; i++)
        {
            // Verificamos si el número es par
            if (i % 2 == 0)
            {
                sumPares += i; 
            }
        }

        Console.WriteLine($"La suma de los números pares en el rango [{X}, {Y}] es: {sumPares}");
    }
}
