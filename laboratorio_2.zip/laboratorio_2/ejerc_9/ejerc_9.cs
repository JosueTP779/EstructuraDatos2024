﻿using System;

class Cadena
{
    static int ContVoca(string texto)
    {
        int cont = 0;
        // convertir todo a minusculas
        texto = texto.ToLower();

        // iterar a cada valor
        foreach (char caracter in texto)
        {
            // confirmamos el caracter que se vocal para el conteo
            if ("aeiou".Contains(caracter))
            {
                cont++;
            }
        }

        return cont;
    }

    static void Main(string[] args)
    {
        Console.WriteLine("ingrese una frase:");
        string texto = Console.ReadLine();

        int numVocales = ContVoca(texto);

        Console.WriteLine($"El número de vocales en el texto es: {numVocales}");
    }
}
