﻿using System;

class Cuadrática
{
    static int Exponente_2(int num)
    {
        return num * num;
    }

    static void Main(string[] args)
    {
        // recorrido para los 10 primeros números
        for (int i = 1; i <= 10; i++)
        {
            // Nmobramos a la funcion
            int cuadrado = Exponente_2(i);
            // Imprime el resultado
            Console.WriteLine($"El cuadrado de {i} es {cuadrado}");
        }
    }
}

